import tkinter as tk
from tkinter import messagebox

class LoginApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Login")
        
        self.email_label = tk.Label(root, text="Email:")
        self.email_label.pack()
        self.email_entry = tk.Entry(root)
        self.email_entry.pack()

        self.password_label = tk.Label(root, text="Password:")
        self.password_label.pack()
        self.password_entry = tk.Entry(root, show="*")
        self.password_entry.pack()

        self.login_button = tk.Button(root, text="Login", command=self.login)
        self.login_button.pack()

    def login(self):
        email = self.email_entry.get()
        password = self.password_entry.get()

        if "@" not in email:
            messagebox.showerror("Erro", "Email inválido!")
            return
        if len(password) <= 6:
            messagebox.showerror("Erro", "Senha deve ter mais de 6 dígitos!")
            return
        
        messagebox.showinfo("Sucesso", "Login realizado com sucesso!")

if __name__ == "__main__":
    root = tk.Tk()
    app = LoginApp(root)
    root.mainloop()
